"""
Read file into texts and calls.
It's ok if you don't understand how to read files
"""
import csv
with open('texts.csv', 'r') as f:
    reader = csv.reader(f)
    texts = list(reader)

with open('calls.csv', 'r') as f:
    reader = csv.reader(f)
    calls = list(reader)

"""
TASK 2: Which telephone number spent the longest time on the phone
during the period? Don't forget that time spent answering a call is
also time spent on the phone.
Print a message:
"<telephone number> spent the longest time, <total time> seconds, on the phone during 
September 2016.".
"""


def get_call_durations(calls):
    temp_dict = {}
    for detail in calls:
        if detail[0] in temp_dict:
            temp_dict[detail[0]] += int(detail[3])
        else:
            temp_dict[detail[0]] = int(detail[3])
        if detail[1] in temp_dict:
            temp_dict[detail[1]] += int(detail[3])
        else:
            temp_dict[detail[1]] = int(detail[3])
    return temp_dict

def who_is_always_on_call(calls):
    temp_dict = get_call_durations(calls)
    max_duration = max(temp_dict.values())
    max_num = [i for i, j in temp_dict.items() if j == max_duration]
    return max_num[0], max_duration

talkitive, duration = who_is_always_on_call(calls)

print("{} spent the longest time, {} seconds, on the phone during September 2016.".format(talkitive, duration))